#include<stdio.h>
#include<string.h>
#include<time.h>
#include<stdlib.h>

char line[100];
char* getValueFromKey(FILE *fin,char *str,int fieldToSkip)
{
	while(1)
	{
		fscanf(fin,"%s",line);
		if(feof(fin)) break;
		if(strcmp(line,str)==0)
		{
			int i;
			//Skipping
			for(i=0;i<fieldToSkip;i++)
			fscanf(fin,"%s",line);
			fscanf(fin,"%s",line);

			return line;
		}
	}
	return NULL;
}
void printCPU()
{
	FILE *fin = fopen("/proc/cpuinfo","r");
	char *str;
	printf("CPU Info\n-----------------------------\n\n");
	while((str=getValueFromKey(fin,"processor",1))!=NULL)
	{
		printf("Processor %s\n",str);
		str = getValueFromKey(fin,"cpu",0);//cpu family
		str = getValueFromKey(fin,"cpu",2);//cpu MHz
		printf("\tClock Speed\t: %sMhz\n", str);
		str = getValueFromKey(fin,"cores",1);//cores
		printf("\tCores\t\t : %sMhz\n\n", str);


	}

	fclose(fin);
}
void printKernal()
{
	FILE *fin = fopen("/proc/version","r");
	char str[1000];
	printf("Kernal Version\n-----------------------------\n\n");
	while(1)
	{
		fscanf(fin,"%s",str);
		if(feof(fin)) break;
		printf("%s ",str);

	}
	printf("\n\n");
	fclose(fin);
}
void printAvgLoad()
{
	FILE *fin = fopen("/proc/version","r");
	char *str;
	float f;
	fscanf(fin,"%f",&f);//1min
	fscanf(fin,"%f",&f);//5min
	fscanf(fin,"%f",&f);//15min

	printf("Average Load (last 15 min) %f: \n\n",f);
	fclose(fin);
}
void printMemFree()
{
	FILE *fin = fopen("/proc/meminfo","r");
	char str[1024];
	float f;
	printf("Memory Info\n------------\n");
	fgets(str,1024,fin);//memTotal
	printf("%s\n",str );
	fgets(str,1024,fin);//memFree
	printf("%s\n",str );

	fclose(fin);
}
void printSwapMem()
{
	FILE *fin = fopen("/proc/meminfo","r");
	char *str;
	printf("Swap Info\n-----------------------------\n\n");

	str = getValueFromKey(fin,"SwapTotal:",0);//swap total
	printf("Total Swap : %s kb\n",str);
	
	fclose(fin);

	fin = fopen("/proc/swaps","r");
	fscanf(fin,"%*s %*s %*s %*s %*s %*s %*s %*s %s",str);//Space Used
	printf("Swap Used : %s kb\n",str);
	
	printf("\n\n");
	fclose(fin);
}

void printSwapDetails()
{
	FILE *fin = fopen("/proc/swaps","r");
	char *str;
	printf("Swap Details\n-----------------------------\n\n");
	fscanf(fin,"%*s %*s %*s %*s %*s");//Ignore 
	int c=0;
	while(1)
	{
		fscanf(fin,"%s",str);//Read
		if(feof(fin))break;
		printf("%s ",str );
		c++;
		if(c%5==0)printf("\n");
	}
	fclose(fin);

}
void printBootTime()
{
	FILE *fin = fopen("/proc/stat","r");
	char *str;
	str = getValueFromKey(fin,"ctxt",0);//Before Boot Time
	long tim;
	fscanf(fin,"btime\t%ld",&tim);//Read
	time_t now = tim;
	printf("\n------------------------\nBoot Time : %s\n-----------------------------\n\n",ctime(&now));

	fclose(fin);

}
void printCpuTime()
{
	FILE *fin = fopen("/proc/stat","r");
	char *str;
	str = getValueFromKey(fin,"cpu",0);//For all core together
	int user,kernal;
	fscanf(fin,"%d %*d %d",&user,&kernal);
	printf("\nTime Spend By CPU\n-----------------------------\n User Mode : %d sec  \n Kernal Mode : %d sec \n\n",user,kernal);

	fclose(fin);

}

void printNoOfContextSwitch()
{
	FILE *fin = fopen("/proc/stat","r");
	char *str;
	str = getValueFromKey(fin,"ctxt",0);//Context Switchs
	printf("\n------------------------\nContext Switchs : %s\n-----------------------------\n\n",str);

	fclose(fin);

}
void printNoOfInterupts()
{
	FILE *fin = fopen("/proc/stat","r");
	char *str;
	str = getValueFromKey(fin,"intr",0);//No. Of Intrupts
	printf("\n------------------------\nNo. Of Intrupts : %s\n-----------------------------\n\n",str);

	fclose(fin);

}

int main(int argc, char const *argv[])
{
	printCPU();
	printKernal();
	printAvgLoad();
	printMemFree();
	printSwapMem();
	printSwapDetails();
	printCpuTime();
	printNoOfContextSwitch();
	printNoOfInterupts();
	printBootTime();
	return 0;
}
